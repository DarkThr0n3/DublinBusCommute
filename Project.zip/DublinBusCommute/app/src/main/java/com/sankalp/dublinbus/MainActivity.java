package com.sankalp.dublinbus;

import android.content.Intent;
import android.icu.util.Calendar;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    MyAdapter mAdapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        new childOperation().execute();

        //  savedInstanceState.getParcelableArray("sdfadsf") In maps acitivityyy

        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



         recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        // use this setting to
        // improve performance if you know that changes
        // in content do not change the layout size
        // of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // use a linear layout manager
        LinearLayoutManager    layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


//
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                new childOperation().execute();
//            }
//        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * @return content from url or null
     */
    private String getStringFromWeb(String url1) {

        try {
            URL url = new URL(url1);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

            StringBuilder builder = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                builder.append(inputLine);
            in.close();

            return builder.toString();

        } catch (IOException ex) {
            // there was some connection problem, or the file did not exist on the server,
            // or your URL was not in the right format.
            // think about what to do now, and put it here.
            ex.printStackTrace(); // for now, simply output it.
        }
        return null;

    }

    public static  List<Bus> listOfBus;

    private class childOperation extends AsyncTask<String, Void, List<Bus>> {

        String data;

        @Override
        protected List<Bus> doInBackground(String... params) {
            data = "";
            listOfBus = new ArrayList<>();

            try {
                // In below query , INSERT CURRENT TIME AND DATE - WHEN ARE YOU TRAVELLING
                //Extract proper time for next query
                Date d = new Date();

                String hour = new SimpleDateFormat("HH").format(d);
                String minute = new SimpleDateFormat("mm").format(d);
                //Log.d("Time----------","Current time of the day using Date - 12 hour format: " + formattedDate);
                String xml_string = getStringFromWeb("https://journeyplanner.transportforireland.ie/nta/XSLT_DM_REQUEST?coordOutputFormat=WGS84[dd.ddddd]&command=&language=en&itdLPxx_useJs=1&std3_suggestMacro=std3_suggest&std3_commonMacro=dm&itdLPxx_contractor=&std3_contractorMacro=&includeCompleteStopSeq=1&mergeDep=1&mode=direct&useAllStops=1&name_dm=name_dm=Dublin%2C+O'Connell+St+Upper%2C+stop+281&nameInfo_dm=51013668%3A$ZN&type_dm=any&itdDateDayMonthYear=15.04.2019&itdTime=" + hour + "%3A" + minute + "&itdLPxx_snippet=1&itdLPxx_template=dmresults&_=1554066061127"); //Stop 281 for o connel ---name_dm=Dublin%2C+O'Connell+St+Upper%2C+stop+281&nameInfo_dm=51013668 ||896 name_dm=Rathgar%2C+Palmerston+Park%2C+stop+896&nameInfo_dm=51014212
                //Returns Bus Departing TIME AND ROUTE
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                InputStream stream = new ByteArrayInputStream(xml_string.getBytes());
                Document doc = dBuilder.parse(stream);
                //doc has
                doc.getDocumentElement().normalize();
                Element rootElement = doc.getDocumentElement();
                NodeList rootChilds = rootElement.getElementsByTagName("div");

                Element std3_dm_box = null;

                for (int i = 0; i < rootChilds.getLength(); i++) {
                    Element element = (Element) rootChilds.item(i);
                    if ("std3_dm_box".equals(element.getAttribute("id"))) {
                        std3_dm_box = element;
                        break;
                    }
                }

                std3_dm_box = (Element) std3_dm_box.getElementsByTagName("div").item(4); //std3_row,  <div class="std3_filtered-stop-box-item">

                Log.e("MA", "div class: " + std3_dm_box.getAttribute("class"));

                NodeList buses = std3_dm_box.getElementsByTagName("div");

                

                for (int i = 0; i < buses.getLength(); i++) {
                    Element element = (Element) buses.item(i);


                    if (element.hasAttribute("data-key")) {

                        String date = element.getAttribute("data-date");
                        String time = element.getAttribute("data-time");
                        String stop = element.getAttribute("data-stop");
                        String key = element.getAttribute("data-key");
                        String drawLine = element.getAttribute("data-draw-line");

                        Bus b1 = new Bus(date, time, stop, key, drawLine);

                        listOfBus.add(b1);

                        String jsonString = getStringFromWeb(
                                String.format("https://journeyplanner.transportforireland.ie/nta/XML_STOPSEQCOORD_REQUEST?&jsonp=jsonpFn6&line=%s&stop=%s&tripCode=%s&date=%s&time=%s&coordOutputFormat=WGS84[DD.DDDDD]&coordListOutputFormat=string&outputFormat=json&tStOTType=NEXT&hideBannerInfo=1"
                                        , URLEncoder.encode(drawLine, "UTF-8")
                                        , stop, key, date, time));

                        JSONObject jo = new JSONObject(jsonString.replace("jsonpFn6(", ""));
                        b1.setJSONresponse(jo);


                        JSONArray ja_stopseq = b1.return_Jarray();


                        for (int ii = 0; ii < ja_stopseq.length(); ii++) {

                            JSONObject jo0 = ja_stopseq.getJSONObject(ii);
                            JSONObject join = ja_stopseq.getJSONObject(ii).getJSONObject("ref");


                            data += "\n\n" + jo0.getString("name") + "\nArr Delay:" + join.getString("arrDelay") + "\nDeparture Delay:" + join.getString("depDelay");
                        }


                        String coods = jo.getJSONObject("stopSeqCoords").getJSONObject("coords").getString("path");

                        b1.setCoods(coods);


                        data += "\n\n\n";

                    }
                }


                //doc.getDocumentElement().getNodeName();  //------GIVES FIRST CLASS NAME INSIDE XML
                //System.out.println("----------------------------");


            } catch (Exception e) {
                e.printStackTrace();
            }

            return listOfBus;
        }

        @Override
        protected void onPostExecute(List<Bus> data) {//https://journeyplanner.transportforireland.ie/nta/XML_STOPSEQCOORD_REQUEST?&jsonp=jsonpFn6&line=irl:60140: :R:d12&stop=51014212&tripCode=630&date=20190401&time=2230&coordOutputFormat=WGS84[DD.DDDDD]&coordListOutputFormat=string&outputFormat=json&tStOTType=NEXT&hideBannerInfo=1
//            View view = MainActivity.this.findViewById(R.id.parent);
//
//            Snackbar.make(view, "Data: " + data, Snackbar.LENGTH_LONG)
//                    .setAction("DISMISS", null).show();

          //  TextView tv = MainActivity.this.findViewById(R.id.textview);
         ///   tv.setText(this.data);

            if (listOfBus.size() != 0) {
                mAdapter = new MyAdapter(MainActivity.this, listOfBus);
                recyclerView.setAdapter(mAdapter);



        }
        }


    }


}


