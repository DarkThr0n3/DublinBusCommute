package com.sankalp.dublinbus;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Bus implements Parcelable {
    private   String date ;
    private   String time ;
    private   String stop ;
    private   String key ;
    private  String drawLine;
    private JSONObject JSONresponse;
    private String coods;

    public String getCoods() {
        return coods;
    }

    public void setCoods(String coods) {
        this.coods = coods;
    }





    public Bus(String date, String time, String stop, String key, String drawLine)  {
        this.date = date;
        this.time = time;
        this.stop = stop;
        this.key = key;
        this.drawLine = drawLine;
    }

    public JSONArray return_Jarray() throws JSONException {
        JSONObject jo = JSONresponse;
        JSONArray ja_stopseq = jo.getJSONObject("stopSeqCoords").getJSONObject("params").getJSONArray("stopSeq");
        return ja_stopseq;
    }

    public void setJSONresponse(JSONObject JSONresponse) {
        this.JSONresponse = JSONresponse;
    }

    public JSONObject getJSONresponse() {
        return JSONresponse;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStop() {
        return stop;
    }

    public void setStop(String stop) {
        this.stop = stop;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDrawLine() {
        return drawLine;
    }

    public void setDrawLine(String drawLine) {
        this.drawLine = drawLine;
    }




    protected Bus(Parcel in) {
        date = in.readString();
        time = in.readString();
        stop = in.readString();
        key = in.readString();
        drawLine = in.readString();
        try {
            JSONresponse = in.readByte() == 0x00 ? null : new JSONObject(in.readString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        coods = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(date);
        dest.writeString(time);
        dest.writeString(stop);
        dest.writeString(key);
        dest.writeString(drawLine);
        if (JSONresponse == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeString(JSONresponse.toString());
        }
        dest.writeString(coods);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Bus> CREATOR = new Parcelable.Creator<Bus>() {
        @Override
        public Bus createFromParcel(Parcel in) {
            return new Bus(in);
        }

        @Override
        public Bus[] newArray(int size) {
            return new Bus[size];
        }
    };
}